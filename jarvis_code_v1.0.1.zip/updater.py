"""
updater.py — JARVIS Auto-Updater
Checks GitHub Releases on every startup and self-updates if newer version found.

Set GITHUB_REPO to your repo (e.g. "artinrexhepi/jarvis") — that's the only
thing you ever need to change in this file.

Debug log is always written to: %APPDATA%\JARVIS\updater.log
Check that file if the updater seems to not be running.
"""

import os
import sys
import time
import zipfile
import io
import subprocess
import requests

# ── ONLY THING YOU CHANGE ─────────────────────────────────────────────────────
GITHUB_REPO = "ArtinSHF/Jarvis-ai-assistant"   # e.g. "artinrexhepi/jarvis"
# ─────────────────────────────────────────────────────────────────────────────

RELEASES_URL = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"
ASSET_PREFIX = "jarvis_code_"

_message_cb = None


def set_message_callback(cb):
    global _message_cb
    _message_cb = cb


# ── Logging ───────────────────────────────────────────────────────────────────

def _log(text):
    """Write to both console and %APPDATA%\JARVIS\updater.log"""
    print(f"[Updater] {text}")
    try:
        log_dir = os.path.join(os.environ.get('APPDATA', ''), 'JARVIS')
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(log_dir, 'updater.log')
        stamp = time.strftime('%Y-%m-%d %H:%M:%S')
        with open(log_path, 'a', encoding='utf-8') as f:
            f.write(f"[{stamp}] {text}\n")
    except Exception:
        pass


def _ui(text):
    """Send text to JARVIS chat UI and log it."""
    _log(text)
    if _message_cb:
        try:
            _message_cb(text)
        except Exception:
            pass


# ── Path helpers ──────────────────────────────────────────────────────────────

def _install_dir():
    """
    Find the JARVIS root folder reliably.

    Strategy 1 (installed via JARVIS.exe):
      sys.executable = <root>/python/python.exe
      root           = two levels up

    Strategy 2 (running jarvis.py directly / dev mode):
      sys.argv[0] = <root>/jarvis.py
      root        = one level up from that

    Whichever gives us a folder that actually contains jarvis.py wins.
    """
    # Strategy 1 — installed mode
    candidate = os.path.dirname(os.path.dirname(os.path.abspath(sys.executable)))
    if os.path.exists(os.path.join(candidate, 'jarvis.py')):
        return candidate

    # Strategy 2 — dev/direct mode
    candidate2 = os.path.dirname(os.path.abspath(sys.argv[0]))
    if os.path.exists(os.path.join(candidate2, 'jarvis.py')):
        return candidate2

    # Last resort — current working directory
    return os.getcwd()


def _version_file():
    return os.path.join(_install_dir(), 'version.txt')


def _local_version():
    try:
        with open(_version_file(), 'r') as f:
            v = f.read().strip().lstrip('v')
            return v if v else '0.0.0'
    except FileNotFoundError:
        _log(f"version.txt not found at {_version_file()} — treating as 0.0.0")
        return '0.0.0'
    except Exception as e:
        _log(f"Could not read version.txt: {e}")
        return '0.0.0'


def _parse(v):
    try:
        return tuple(int(x) for x in v.strip().lstrip('v').split('.'))
    except Exception:
        return (0, 0, 0)


# ── Main update check ─────────────────────────────────────────────────────────

def check_for_updates():
    """
    Run in a background thread from jarvis.py on_start().
    Writes everything to updater.log so you can always see what happened.
    """
    try:
        # Clear log at start of each session so it doesn't grow forever
        try:
            log_path = os.path.join(os.environ.get('APPDATA', ''), 'JARVIS', 'updater.log')
            with open(log_path, 'w') as f:
                f.write(f"=== JARVIS Updater — {time.strftime('%Y-%m-%d %H:%M:%S')} ===\n")
        except Exception:
            pass

        time.sleep(6)  # let JARVIS fully boot first

        install = _install_dir()
        local   = _local_version()

        _log(f"Install dir   : {install}")
        _log(f"Local version : v{local}")
        _log(f"Checking      : {RELEASES_URL}")

        # ── Hit GitHub API ────────────────────────────────────────────────────
        try:
            r = requests.get(
                RELEASES_URL,
                timeout=10,
                headers={'User-Agent': 'JARVIS-Updater/1.0'}
            )
        except requests.exceptions.ConnectionError:
            _log("No internet connection — skipping update check.")
            return
        except requests.exceptions.Timeout:
            _log("GitHub API request timed out — skipping.")
            return

        _log(f"GitHub API status: {r.status_code}")

        if r.status_code == 404:
            _log("404 — repo not found or no releases published yet.")
            _log(f"Check that GITHUB_REPO = '{GITHUB_REPO}' is correct and the repo is PUBLIC.")
            return
        if r.status_code != 200:
            _log(f"Unexpected status {r.status_code} — skipping.")
            return

        release  = r.json()
        tag      = release.get('tag_name', '').strip()
        latest   = tag.lstrip('v')
        is_draft = release.get('draft', False)
        is_pre   = release.get('prerelease', False)

        _log(f"Latest release: {tag}  (draft={is_draft}  prerelease={is_pre})")

        if not latest:
            _log("No tag_name found in the release response — skipping.")
            return

        if is_draft:
            _log("Latest release is a DRAFT — skipping. Publish it to make it available.")
            return

        # ── Compare versions ──────────────────────────────────────────────────
        if _parse(latest) <= _parse(local):
            _log("Already up to date.")
            return

        _log(f"Update available: v{local} → v{latest}")

        # ── Find the code zip asset ───────────────────────────────────────────
        assets = release.get('assets', [])
        _log(f"Release has {len(assets)} asset(s): {[a['name'] for a in assets]}")

        zip_asset = next(
            (a for a in assets
             if a['name'].startswith(ASSET_PREFIX) and a['name'].endswith('.zip')),
            None
        )

        if not zip_asset:
            _log(f"No asset starting with '{ASSET_PREFIX}' found.")
            _log("Make sure you attached jarvis_code_vX.Y.Z.zip to the GitHub release.")
            return

        _log(f"Found asset: {zip_asset['name']}  ({zip_asset['size']:,} bytes)")
        _apply_update(latest, zip_asset['browser_download_url'], install)

    except Exception as e:
        _log(f"Unexpected error in check_for_updates: {e}")
        import traceback
        _log(traceback.format_exc())


def _apply_update(new_version, url, install_dir):
    """Download zip into RAM, extract to install dir, restart."""
    try:
        _ui(f"Update available: v{new_version} — downloading...")
        _log(f"Downloading from: {url}")

        resp  = requests.get(url, timeout=60, stream=True)
        total = int(resp.headers.get('content-length', 0))
        buf   = io.BytesIO()
        done  = 0

        for chunk in resp.iter_content(chunk_size=8192):
            buf.write(chunk)
            done += len(chunk)
            if total:
                print(f"\r[Updater] Downloading... {int(done*100/total)}%",
                      end='', flush=True)
        print()

        _log(f"Downloaded {done:,} bytes.")
        buf.seek(0)

        _ui(f"Installing v{new_version}...")

        # Verify it's a valid zip before touching anything
        if not zipfile.is_zipfile(buf):
            _log("Downloaded file is not a valid zip — aborting update.")
            _ui("Update failed: downloaded file was invalid.")
            return

        buf.seek(0)
        with zipfile.ZipFile(buf, 'r') as z:
            names = z.namelist()
            _log(f"Zip contains {len(names)} files: {names}")
            for member in names:
                target = os.path.realpath(os.path.join(install_dir, member))
                if not target.startswith(os.path.realpath(install_dir)):
                    _log(f"Blocked unsafe path: {member}")
                    continue
                z.extract(member, install_dir)
                _log(f"Extracted: {member}")

        _log("All files extracted successfully.")
        _ui(f"JARVIS updated to v{new_version} — restarting...")
        time.sleep(2)
        _restart(install_dir)

    except Exception as e:
        _log(f"Error during update: {e}")
        import traceback
        _log(traceback.format_exc())
        _ui(f"Update failed — check updater.log in %APPDATA%\\JARVIS\\")


def _restart(install_dir):
    python = sys.executable
    script = os.path.join(install_dir, 'jarvis.py')
    _log(f"Restarting: {python} {script}")
    subprocess.Popen([python, script] + sys.argv[1:], cwd=install_dir)
    os._exit(0)
